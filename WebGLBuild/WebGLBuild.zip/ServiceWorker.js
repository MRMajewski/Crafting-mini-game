const cacheName = "MadMonkStudio-Crafting Island-1.04";
const contentToCache = [
    "Build/d9d605cb1c18b4ed9fb179406f02ceab.loader.js",
    "Build/004814479daca53386ce4fa580cd0d1e.framework.js.unityweb",
    "Build/35125686e0a3c9be6bd390244885d5bb.data.unityweb",
    "Build/28af26fcace0e80123489f4f8fa1472c.wasm.unityweb",
    "TemplateData/style.css"

];

self.addEventListener('install', function (e) {
    console.log('[Service Worker] Install');
    
    e.waitUntil((async function () {
      const cache = await caches.open(cacheName);
      console.log('[Service Worker] Caching all: app shell and content');
      await cache.addAll(contentToCache);
    })());
});

self.addEventListener('fetch', function (e) {
    e.respondWith((async function () {
      let response = await caches.match(e.request);
      console.log(`[Service Worker] Fetching resource: ${e.request.url}`);
      if (response) { return response; }

      response = await fetch(e.request);
      const cache = await caches.open(cacheName);
      console.log(`[Service Worker] Caching new resource: ${e.request.url}`);
      cache.put(e.request, response.clone());
      return response;
    })());
});
